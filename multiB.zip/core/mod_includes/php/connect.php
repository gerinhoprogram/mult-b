<?php 
require_once("ctracker.php"); 
require_once("parametros.php");

$sis_url = isset($isi_url) ? $sis_url : '';
if($sis_url == ""){
	$ex = explode('/', $SERVER['PHP_SELF']);
	$sis_url = $ex[count($ex)-5];
}

error_reporting(1);
date_default_timezone_set('America/Sao_Paulo');
define( 'MYSQL_HOST', 'localhost' );
define( 'MYSQL_PORT', '3306' );
define( 'MYSQL_USER', 'multib_site' );
define( 'MYSQL_PASSWORD', 'multi@2020' );
define( 'MYSQL_DB_NAME', 'multib_site' );

try
{
    $PDO = new PDO( 'mysql:host=' . MYSQL_HOST . ';port=' . MYSQL_PORT . ';dbname=' . MYSQL_DB_NAME, MYSQL_USER, MYSQL_PASSWORD );
}
catch ( PDOException $e )
{
    echo 'Erro ao conectar com o MySQL: ' . $e->getMessage();
}
$PDO->exec("SET CHARACTER SET utf8");
$PDO->setAttribute( PDO::ATTR_EMULATE_PREPARES, false );
?>

